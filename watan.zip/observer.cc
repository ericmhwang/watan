#include "observer.h"

void Observer::notify(Goal &goal) {}

void Observer::notify(Criteria &criteria) {}

void Observer::notify(Tile &tile) {}

Observer::~Observer() {}
